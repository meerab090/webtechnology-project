<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Thank You | TUF Concert</title>
   <link rel="stylesheet" href="style.css">


</head>
<body>

<section class="thankyou">
    <div class="thankyou-box">
        <h1>Thank You for Registering!</h1>
        <p>We can’t wait to see you at the TUF Concert Night.</p>
        <div class="thankyou-icons">🎵 ⭐ 🌠</div>
        <div class="thankyou-buttons">
            <a href="index.php" class="btn-blue">Back to Home</a>
            <a href="#" class="btn-yellow">Have Fun</a>
        </div>
    </div>
</section>

</body>
</html>