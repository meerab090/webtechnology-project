<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Artists | TUF Concert</title>
    <link rel="stylesheet" href="style.css">

</head>
<body>

<header class="nav-header">
    <div class="nav-container">
        <h2 class="logo">TUF Concert</h2>
        <nav>
            <a href="index.php">Home</a>
            <a href="about.php">About</a>
            <a href="artists.php" class="active">Artists</a>
            <a href="register.php" class="btn-yellow">Register</a>
        </nav>
    </div>
</header>

<div class="artists-container">
    <h1>View Artists</h1>
    <p class="subtitle">Explore the talented artists performing at TUF Concert Night.</p>

    <div class="artist-cards">

    <div class="artist-card pink-card">
        <div class="image-container">
            <img src="images/hassan.jpg" alt="Hassan Raheem">
        </div>
        <div class="artist-info">
            <h2>Hassan Raheem</h2>
            <p>Hip-hop Artist</p>
        </div>
    </div>

    <div class="artist-card blue-card">
        <div class="image-container">
            <img src="images/jaffer.jpg" alt="Jaffer Shah">
        </div>
        <div class="artist-info">
            <h2>Jaffer Shah</h2>
            <p>Indie Singer-Songwriter</p>
        </div>
    </div>

</div>