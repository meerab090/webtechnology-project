<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>About | TUF Concert Night</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<header class="nav-header">
    <div class="nav-container">
        <h2 class="logo">TUF Concert</h2>
        <nav>
            <a href="index.php">Home</a>
            <a href="about.php" class="active">About</a>
            <a href="artists.php">Artists</a>
            <a href="register.php" class="btn-yellow">Register</a>
        </nav>
    </div>
</header>

<section class="about-section">
    <div class="about-content">
        <div class="about-text">
            <h1>About TUF Concert Night</h1>
            <p>
                TUF Concert Night brings together top artists, high-energy performances,
                fun activities, and a night full of music you don’t want to miss.
            </p>
        </div>
        <div class="about-image">
            <img src="images/about-illustration.png" alt="Illustration">
        </div>
    </div>

    <div class="about-box">
        <h2>What Makes Us Special</h2>
        <div class="about-cards">
            <div class="about-card pink">
                <h3>🎉 Pop Theme Decorations</h3>
                <p>Bright and colorful</p>
            </div>
            <div class="about-card blue">
                <h3>⚡ High-Energy Stage</h3>
                <p>Stunning visual effects</p>
            </div>
            <div class="about-card yellow">
                <h3>💖 Memories That Last Forever</h3>
                <p>Creating unforgettable moments</p>
            </div>
        </div>
    </div>
</section>

<div class="event-bar">
    <span>📅 15 December 2025</span>
    <span>⏰ 7 PM onwards</span>
    <span>📍 TUF Ground</span>
    <a href="register.php" class="btn-yellow">Register Now</a>
</div>

</body>
</html>