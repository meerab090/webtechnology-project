<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>TUF Concert Night 2025</title>
    <link rel="stylesheet" href="style.css">

</head>
<body>

<header class="nav-header">
    <div class="nav-container">
        <h2 class="logo">TUF Concert</h2>
        <nav>
            <a href="index.php" class="active">Home</a>
            <a href="about.php">About</a>
            <a href="artists.php">Artists</a>
            <a href="register.php" class="btn-yellow">Register</a>
        </nav>
    </div>
</header>

<section class="hero">
    <div class="hero-content">
        <h1>TUF Concert<br>Night 2025</h1>
        <p>Live · Loud · Legendary</p>
        <div class="hero-buttons">
            <a href="register.php" class="btn-yellow">Register Now</a>
            <a href="artists.php" class="btn-outline">View Artists</a>
        </div>
    </div>
</section>

<section class="highlights">
    <div class="highlight-card purple">
        🎵
        <h3>Top DJs & Artists</h3>
        <p>Experience quality live music</p>
    </div>
    <div class="highlight-card purple">
        ⭐
        <h3>Laser & Light Show</h3>
        <p>Amazing visual effects</p>
    </div>
    <div class="highlight-card purple">
        🎤
        <h3>Food · Drinks · Fun</h3>
        <p>Enjoy everything</p>
    </div>
</section>

<section class="event-info">
    <div class="info">
        📅 15 December 2025<br>
        ⏰ 7 PM onwards<br>
        📍 TUF Ground
    </div>
    <a href="register.php" class="btn-yellow">Register Now</a>
</section>

</body>
</html>