<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register | TUF Concert</title>
   <link rel="stylesheet" href="style.css">

</head>
<body>

<header class="nav-header">
    <div class="nav-container">
        <h2 class="logo">TUF Concert</h2>
        <nav>
            <a href="index.php">Home</a>
            <a href="about.php">About</a>
            <a href="register.php" class="active">Register</a>
            <a href="artists.php" class="btn-yellow">Artists</a>
        </nav>
    </div>
</header>

<section class="register-section">
    <h1>Register for<br>TUF Concert Night</h1>
    <div class="register-card">
        <form action="save_registration.php" method="POST">

    <label>Full Name</label>
    <input type="text" name="name" placeholder="Full Name" required>

    <label>Email Address</label>
    <input type="email" name="email" placeholder="Email Address" required>

    <label>Phone Number</label>
    <input type="text" name="phone" placeholder="Phone Number" required>

    <label>Number of Tickets</label>
    <input type="number" name="tickets" placeholder="Tickets" min="1" required>

    <button type="submit">Register</button>

</form>

    </div>
</section>

</body>
</html>