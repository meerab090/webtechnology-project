<?php
include 'db.php';

$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$tickets = $_POST['tickets'];

$sql = "INSERT INTO registrations (full_name, email, phone, tickets) 
        VALUES ('$name', '$email', '$phone', '$tickets')";

if (mysqli_query($conn, $sql)) {
    header("Location: thankyou.php");
} else {
    echo "Error: " . mysqli_error($conn);
}
?>
